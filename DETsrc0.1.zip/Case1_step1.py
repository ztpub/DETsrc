import os
import math


# Load miRNA and mRNA expression
MIRNA = {}
MRNA = {}
miT = {}
miTG = {}

f = open("./case1.txt")
lines = f.readlines()
f.close()

for i in range(1,len(lines)):
    ls = lines[i].replace("\n","").split("\t")
    strr = ls[0] + "\t" + ls[1] + "\t" + ls[2] + "\t" + ls[3] + "\t" + ls[4] + "\t" +ls[5] + "\n"
    MIRNA[ls[0]] = strr
    strr = ls[6] + "\t" + ls[7] + "\t" + ls[8] + "\t" + ls[9] + "\t" + ls[10] + "\t" +ls[11] + "\n"
    MRNA[ls[6]] = strr

    miTG[ls[6]] = 1
    try:
        miT[ls[0]].append(ls[6])
    except:
        miT[ls[0]] = [ls[6]]
        
print len(MIRNA.keys())
print len(MRNA.keys())
for mg in miT.keys():
    print mg,miT[mg]

    
# Save avalible miRNA expression
sf = open("./R1-miRNA-expr.txt","w")
for mg in MIRNA.keys():
        sf.write(MIRNA[mg])
sf.close()

# Save avalible mRNA expression
sf = open("./R1-mRNA-expr.txt","w")
for mg in miTG.keys():
    sf.write(MRNA[mg])
sf.close()

# Save avalible miRNA-Target pairs
sf = open("./R1-miRNA-MRNA.txt","w")
for mg in miT.keys():
    for tg in miT[mg]:
        sf.write(mg+"\t"+tg+"\n")
sf.close()

