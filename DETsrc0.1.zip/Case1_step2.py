import os
import math
import scipy.stats
import numpy

# Load prior-known TF list
f = open("./PlnTFDB_rice.txt")
lines = f.readlines()
f.close()

TF = []
for i in range(1,len(lines)):
    ls = lines[i].replace("\n","")
    TF.append(ls)

# Load miRNA expression
f = open("./R1-miRNA-expr.txt")
lines = f.readlines()
f.close()

MIRNA = {}
for i in range(1,len(lines)):
    ls = lines[i].split("\t")
    MIRNA[ls[0]] = lines[i]

# Load mRNA expression
f = open("./R1-mRNA-expr.txt")
lines = f.readlines()
f.close()

MRNA = {}
for i in range(1,len(lines)):
    ls = lines[i].replace("\n","").split("\t")
    V = []
    for j in range(1,len(ls)):
        V.append(float(ls[j]))
    if sum(V)>0:
        MRNA[ls[0]] = lines[i]


# Load miRNA-Target pairs
f = open("./R1-miRNA-MRNA.txt")
lines = f.readlines()
f.close()

miT = {}
miTG = {}
for i in range(0,len(lines)):
    ls = lines[i].replace("\n","").split("\t")
    lss = ls[1].split(".")

    if ls[0] in MIRNA.keys() and lss[0] in MRNA.keys():
        miTG[lss[0]] = 1
        try:
            miT[ls[0]].append(lss[0])
        except:
            miT[ls[0]] = [lss[0]]

##################################################################
##
##################################################################

# Select miRNAs 
sf = open("./R2-nodes.txt","w")
sf.write("ID\ttype\tTF\t1-0\t2-0\t3-0\t4-0\tmax\n")
for mg in MIRNA.keys():
    ls = MIRNA[mg].replace("\n","").split("\t")

    strr = mg + "\tmiRNA"

    if mg in TF:
        strr = strr + "\tTF"
    else:
        strr = strr + "\tNone"

    # Load case and control data !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    V1 = []
    for i in range(1,6):
        V1.append(float(ls[i]))

    # Get fold-changes with 0-point as control !!!!!!!!!!!!!!!!!!!!!!!!!
    FC = []
    for i in range(1,5):
        if V1[i]>0 and V1[0]>0:
            FC.append(math.log(V1[i]/V1[0],2))
        else:
            if V1[i]>0:
                FC.append(5)
            elif V1[0]>0:
                FC.append(-5)
            else:
                FC.append(0)
    for v in FC:
        strr = strr + "\t" + str(v)

    strr = strr + "\t" + str(max(FC))


    sf.write(strr+"\n")

# Select mRNAs

for mg in MRNA.keys():
    ls = MRNA[mg].replace("\n","").split("\t")
    
    strr = mg+ "\tmRNA"

    if mg in TF:
        strr = strr + "\tTF"
    else:
        strr = strr + "\tNone"

    # Load case and control data !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    V1 = []
    V2 = []
    for i in range(1,6):
        V1.append(float(ls[i]))


    # Get fold-changes with 0-point as control !!!!!!!!!!!!!!!!!!!!!!!!!
    FC = []
    for i in range(1,5):
        if V1[i]>0 and V1[0]>0:
            FC.append(math.log(V1[i]/V1[0],2))
        else:
            if V1[i]>0:
                FC.append(5)
            elif V1[0]>0:
                FC.append(-5)
            else:
                FC.append(0)
    for v in FC:
        strr = strr + "\t" + str(v)

    strr = strr + "\t" + str(max(FC))


    sf.write(strr+"\n")
sf.close()

##################################################################
##
##################################################################

# Select miRNA-mRNA pairs

sf = open("./R2-edges.txt","w")
sf.write("miRNA\tmRNA\tPCC\tPv\t1-0\t2-0\t3-0\t4-0\tLocal\tGlobal\n")
FCC = 1.2
for mg in miT.keys():
    for tg in set(miT[mg]):
        strr = mg+"\t"+tg
        ls = MIRNA[mg].replace("\n","").split("\t")

        # Get differential PCC in global pattern
        
        mg_V1 = []
        for i in range(1,6):
            mg_V1.append(float(ls[i]))

        ls = MRNA[tg].replace("\n","").split("\t")
        tg_V1 = []
        for i in range(1,6):
            tg_V1.append(float(ls[i]))


        [Z1,P1] = scipy.stats.pearsonr(mg_V1,tg_V1) # PCC 


        strr = strr + "\t" + str(Z1)+"\t"+str(P1)

        # Get differential pattern / negative pattern in local pattern
        gn = 0
        ln = 0
        for i in range(1,5):
            fc = 1
            if mg_V1[i]>0 and mg_V1[0]>0:
                fc = mg_V1[i]/mg_V1[0]
            else:
                if mg_V1[i]>0:
                    fc = 10
                if mg_V1[0]>0:
                    fc = 0.1

            fct = 1
            if tg_V1[i]>0 and tg_V1[0]>0:
                fct = tg_V1[i]/tg_V1[0]
            else:
                if tg_V1[i]>0:
                    fct = 10
                if tg_V1[0]>0:
                    fct = 0.1

            if fc>=FCC and fct<=1./FCC:
                strr = strr + "\tgain"
                gn = gn + 1
            elif fc<=1./FCC and fct>FCC:
                strr = strr + "\tloss"
                ln = ln + 1
            else:
                strr = strr + "\t-"

        local = '-'
        globa = '-'
        if (gn>=1 and ln==0) or (gn==0 and ln>=1): 
            local = 'Local'
        if (P1<=0.05 and Z1<0): 
            globa = 'Global'

        if local=='Local' or globa=='Global':
            sf.write(strr + "\t" + local + "\t" + globa+"\n")
sf.close()
                
